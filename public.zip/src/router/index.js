import index from '../pages/site/index.vue'
import {createRouter, createWebHistory} from "vue-router";
import service from "../pages/site/service.vue";
import base from "../pages/site/base.vue";
import designer from "../pages/site/designer.vue";

const routes = [
    {
        path:'/',
        component:index,
        name:"main"
    },
    {
        path: '/index',
        component: base,
        name:'base',
        children:[
            {
                path:'',
                component:base,
            },
            {
                path:'service/:page',
                component:service,
                name:'service',
            },
            {
                path:"/constructor/:name",
                component:designer,
                name:'constructor'
            }

        ],
    }
]

export default new createRouter({
    history: createWebHistory(),
    linkActiveClass: 'active-link',
    routes
})