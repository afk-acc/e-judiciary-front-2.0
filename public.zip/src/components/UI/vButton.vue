<template>
  <div class="rounded-[50px] bg-white text-link px-9 py-4 font-bold cursor-pointer">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "vButton"
}
</script>

<style scoped>

</style>