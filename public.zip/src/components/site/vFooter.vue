<template>
  <div class="bg-footer_bg py-10">
    <div class="_container flex justify-between flex-wrap">
      <div class="flex flex-col gap-y-5 max-w-[250px]">
        <div class="">
          <img src="/ejudiciary2.svg" alt="" class="w-[150px] h-[50px]">
        </div>
        <p class="text-gray">Home Business Meaning of Job Application or Employment Application BUSINESS</p>
      </div>
      <div class="flex flex-wrap gap-y-5 gap-x-10">
        <div class="">
          <p class="text-primary font-bold text-2xl cursor-pointer"> {{ $t('Услуги') }}</p>
          <ul class="text-gray text-xl flex flex-col gap-y-3 mt-3">
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
          </ul>
        </div>
        <div class="">
          <p class="text-primary font-bold text-2xl cursor-pointer"> {{ $t('Услуги') }}</p>
          <ul class="text-gray text-xl flex flex-col gap-y-3 mt-3">
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
          </ul>
        </div>
        <div class="">
          <p class="text-primary font-bold text-2xl cursor-pointer"> {{ $t('Услуги') }}</p>
          <ul class="text-gray text-xl flex flex-col gap-y-3 mt-3">
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
            <li class="cursor-pointer">{{ $t('Услуги') }}</li>
          </ul>
        </div>
      </div>

    </div>

  </div>
</template>

<script>
export default {
  name: "vFooter"
}
</script>

<style scoped>

</style>