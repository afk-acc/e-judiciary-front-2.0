<template>
  <div
      class="fixed  w-full border-b-[0.5px] border-white border-opacity-40 h-[65px] z-50">
    <div class="_container flex items-center justify-between relative">


      <div class="w-[150px] h-[50px] relative">
          <img src="/ejudiciary.svg" alt="" class="w-[150px] h-[60px] object-cover">

      </div>
      <ul class="flex gap-x-8 text-white font-bold text-sm">
        <router-link :to="{name:'service', params:{page:1}}" class="cursor-pointer">{{ $t('Услуги') }}</router-link>
        <li class="cursor-pointer">{{ $t('Вопросы') }}</li>
        <li class="cursor-pointer">{{ $t('Юристы') }}</li>
      </ul>
      <ul class="flex gap-x-8 text-white items-center">
        <li>UZ</li>
        <li class="flex items-center gap-x-2 px-5 py-2 hover:bg-white hover:text-link rounded-2xl transition-all duration-300 cursor-pointer font-bold el-hover">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M15.8333 9.16663H4.16667C3.24619 9.16663 2.5 9.91282 2.5 10.8333V16.6666C2.5 17.5871 3.24619 18.3333 4.16667 18.3333H15.8333C16.7538 18.3333 17.5 17.5871 17.5 16.6666V10.8333C17.5 9.91282 16.7538 9.16663 15.8333 9.16663Z"
                stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path
                d="M5.83332 9.16667V5.83334C5.83228 4.80005 6.21522 3.80323 6.90779 3.03639C7.60037 2.26956 8.55317 1.78742 9.58124 1.68358C10.6093 1.57974 11.6393 1.86159 12.4712 2.47443C13.3031 3.08728 13.8777 3.98738 14.0833 5.00001"
                stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          {{ $t('Войти') }}
        </li>
        <li class="flex items-center gap-x-2 px-5 py-2 hover:bg-white hover:text-link rounded-2xl transition-all duration-300 cursor-pointer font-bold el-hover">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M15.8333 9.16663H4.16667C3.24619 9.16663 2.5 9.91282 2.5 10.8333V16.6666C2.5 17.5871 3.24619 18.3333 4.16667 18.3333H15.8333C16.7538 18.3333 17.5 17.5871 17.5 16.6666V10.8333C17.5 9.91282 16.7538 9.16663 15.8333 9.16663Z"
                stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path
                d="M5.83331 9.16663V5.83329C5.83331 4.72822 6.2723 3.66842 7.0537 2.88701C7.8351 2.10561 8.89491 1.66663 9.99998 1.66663C11.105 1.66663 12.1649 2.10561 12.9463 2.88701C13.7277 3.66842 14.1666 4.72822 14.1666 5.83329V9.16663"
                stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          {{ $t('Регистрация') }}
        </li>
      </ul>
    </div>

  </div>

</template>

<script>
export default {
  name: "vHeader"
}
</script>

<style>
.el-hover path {
  transition: all 0.3s;
}

.el-hover:hover path {
  stroke: #2556B5 !important;
}
</style>