<template>
  <div class="">
    <input type="text">
  </div>
</template>

<script>
export default {
  name: "designerInput"
}
</script>

<style scoped>

</style>