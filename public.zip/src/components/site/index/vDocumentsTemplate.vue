<template>
  <div class="bg-primary_gr py-10 text-white font-medium text-3xl">
    <div class="_container">
      <p class="text-center ">{{ $t('Образцы документов') }}</p>
      <div class="flex flex-wrap justify-between gap-y-20 mt-10 relative">
        <document-template-item :item="item" v-for="(item, index) in docList" :key="index" class="w-[49%]"
                                :is-end="index % 2 !== 0" :class="{'border-r ':index % 2 === 0}"/>
      </div>
      <div class="flex justify-center mt-10">
        <v-button>{{$t('Все образцы')}}</v-button>

      </div>

    </div>

  </div>
</template>

<script>
import DocumentTemplateItem from "./DocumentTemplateItem.vue";
import VButton from "../../UI/vButton.vue";

export default {
  name: "vDocumentsTemplate",
  components: {VButton, DocumentTemplateItem},
  computed: {
    docList() {
      return [
        {
          title: this.$t("Контракты"),
          children: [
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            },
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            }
          ]
        },
        {
          title: this.$t("Контракты"),
          children: [
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            },
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            }
          ]
        },
        {
          title: this.$t("Контракты"),
          children: [
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            },
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            }
          ]
        },
        {
          title: this.$t("Контракты"),
          children: [
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            },
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            }
          ]
        },
        {
          title: this.$t("Контракты"),
          children: [
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            },
            {
              name: this.$t('Контракты для юридических лиц')
            },
            {
              name: this.$t('Договоры для юридических лиц')
            }
          ]
        },

      ]
    }
  }
}
</script>

<style scoped>

</style>