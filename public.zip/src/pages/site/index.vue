<template>
  <div class="">
    <v-inner/>
    <div class="_container">
      <v-advantages/>
    </div>
    <v-documents-template/>
    <div class="_container">
      <v-stats/>
    </div>
    <v-info/>
    <v-footer/>
  </div>
</template>

<script>
import vInner from "../../components/site/index/vInner.vue"
import VAdvantages from "../../components/site/index/vAdvantages.vue";
import VDocumentsTemplate from "../../components/site/index/vDocumentsTemplate.vue";
import VStats from "../../components/site/index/vStats.vue";
import VInfo from "../../components/site/index/vInfo.vue";
import VFooter from "../../components/site/vFooter.vue";

export default {
  name: "index",
  components: {
    VFooter,
    VInfo,
    VStats,
    VDocumentsTemplate,
    VAdvantages,
    vInner
  }

}
</script>

<style scoped>

</style>