<template>
  <div class="_container">
    <div class="flex items-center gap-x-4 pt-7">
      <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
            d="M11.4583 4.16666H4.16659C3.61405 4.16666 3.08415 4.38615 2.69345 4.77685C2.30275 5.16755 2.08325 5.69746 2.08325 6.24999V20.8333C2.08325 21.3859 2.30275 21.9158 2.69345 22.3065C3.08415 22.6972 3.61405 22.9167 4.16659 22.9167H18.7499C19.3025 22.9167 19.8324 22.6972 20.2231 22.3065C20.6138 21.9158 20.8333 21.3859 20.8333 20.8333V13.5417"
            stroke="#224EA4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path
            d="M19.2708 2.60418C19.6852 2.18978 20.2472 1.95697 20.8333 1.95697C21.4193 1.95697 21.9814 2.18978 22.3958 2.60418C22.8102 3.01858 23.043 3.58063 23.043 4.16668C23.043 4.75273 22.8102 5.31478 22.3958 5.72918L12.4999 15.625L8.33325 16.6667L9.37492 12.5L19.2708 2.60418Z"
            stroke="#224EA4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      {{ $route.params.name }}
    </div>
    <div class="">
      
    </div>
  </div>
</template>

<script>
export default {
  name: "designer"
}
</script>

<style scoped>

</style>