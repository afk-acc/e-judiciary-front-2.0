<template>
  <div class="min-h-screen flex flex-col justify-between">
    <v-header class="bg-primary_gr"/>
    <router-view class="pt-14"/>
    <v-footer class=""/>
  </div>
</template>

<script>
import VHeader from "../../components/site/vHeader.vue";
import VFooter from "../../components/site/vFooter.vue";

export default {
  name: "base",
  components: {VFooter, VHeader}
}
</script>

<style scoped>

</style>