import uz_l from "./uz_l.json";
import uz_c from "./uz_c.json";
import ru from "./ru.json";

export const defaultLocale = "uz_l";

export const languages = {uz_l, uz_c, ru};
