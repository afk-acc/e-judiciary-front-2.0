import axios from "../axios/index.js";


export default {
    state() {
        return {
            doc_type_list: [],
            all_doc_list:[],
        }

    },
    getters: {
        get_doc_type_list(state) {
            return state.doc_type_list
        },
        get_all_doc_list(state){
            return state.all_doc_list
        }
    },
    mutations: {
        update_doc_type_list(state, data) {
            state.doc_type_list = data
        },
        update_all_doc_list(state, data){
            state.all_doc_list = data
        }
    },
    actions: {
        load_doc_type_list(context) {
            axios.get(`appeal/type_list?locale=${localStorage.getItem('locale')}`).then(res => {
                context.commit('update_doc_type_list', res.data.data)
            })
        },
        load_all_doc_list(context, params){
            axios.get(`appeal/all?page=${params.page}&locale=${localStorage.getItem('locale')}&limit=10`).then(res => {
                context.commit('update_all_doc_list', res.data)
            })
        }
    },
}