import {createStore} from "vuex";
import constructor from "./constructor.js";

export default createStore({
    state(){
        return {}
    },
    getters:{},
    mutations:{},
    actions:{},
    modules:{
        constructor
    },

})