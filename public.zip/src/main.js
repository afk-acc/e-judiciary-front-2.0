import {createApp} from 'vue'
import './style.css'
import App from './App.vue'
import store from "./store/index.js";
import router from "./router/index.js";
import "./style/app.css";
import {languages, defaultLocale} from "./lang/index.js";
import {createI18n} from "vue-i18n";
import axios from "./axios/index.js";
import VueAxios from "vue-axios";

const localeLocalStorage = localStorage.getItem("locale");

const messages = Object.assign(languages);
const i18n = createI18n({
    legacy: false,
    locale: localeLocalStorage || defaultLocale,
    fallbackLocale: "ru",
    messages,
});

const app = createApp(App)

app.use(store);
app.use(router);
app.use(i18n);
app.use(VueAxios, axios);
app.mount('#app')
export default i18n.global.t