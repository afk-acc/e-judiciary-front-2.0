<script >
export default {
  mounted() {
    if (!localStorage.getItem('locale'))
      localStorage.setItem('locale', 'ru')
  },
}

</script>

<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style >
._container{
  max-width: 1190px;
  margin:0 auto;
  width: 100%;
}
.active-link{
  position: relative;
  height: 100%;
}
.active-link::after{
  height: 2px;
  width: 100%;
  background: #fff;
  content: "";
  position: absolute;
  top:100%;
  left:0;
}
</style>
